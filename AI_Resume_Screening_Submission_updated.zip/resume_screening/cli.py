"""Command-line interface."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from .config import Settings
from .pipeline import screen_resumes
from .report import write_html_report


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Screen and rank resumes for Python and AI/agentic evidence.")
    parser.add_argument("--input", required=True, type=Path, help="Folder containing PDF, DOCX, or TXT resumes")
    parser.add_argument("--output", required=True, type=Path, help="Destination JSON result path")
    parser.add_argument("--skip-github", action="store_true", help="Skip public GitHub enrichment")
    parser.add_argument("--enable-llm", action="store_true", help="Enable optional structured LLM enrichment (needs LLM_API_KEY)")
    parser.add_argument("--enable-ocr", action="store_true", help="Use optional OCR only when a PDF has no extractable text")
    parser.add_argument("--html-report", type=Path, help="Optional self-contained HTML insights report path")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if not args.input.is_dir():
        raise SystemExit(f"Input directory does not exist: {args.input}")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    try:
        result = screen_resumes(
            args.input,
            args.output.parent,
            Settings(),
            skip_github=args.skip_github,
            enable_llm=args.enable_llm,
            enable_ocr=args.enable_ocr,
        )
    except ValueError as exc:
        raise SystemExit(str(exc)) from exc
    args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    if args.html_report:
        write_html_report(result, args.html_report)
    summary = result["batch_summary"]
    print(
        f"Processed {summary['total_resume_files']} files: {summary['eligible']} eligible, "
        f"{summary['rejected']} rejected, {summary['failed_unreadable']} failed.\n"
        f"Results: {args.output}"
    )
    if args.html_report:
        print(f"HTML insights: {args.html_report}")
    return 0

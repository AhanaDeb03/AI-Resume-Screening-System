"""File parsing and low-risk contact/profile extraction."""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .models import CandidateResult

EMAIL_RE = re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.I)
GITHUB_RE = re.compile(
    r"(?:https?://)?(?:www\.)?github\.com/([A-Za-z0-9-]+)(?:[/?#][^\s|]*)?",
    re.I,
)

SECTION_HEADINGS: dict[str, tuple[str, ...]] = {
    "summary": ("summary", "profile", "objective", "about me"),
    "skills": ("skills", "technical skills", "core competencies", "tools"),
    "experience": ("experience", "work experience", "employment", "internship"),
    "projects": ("projects", "project experience", "academic projects"),
    "education": ("education", "academic background"),
    "certifications": ("certifications", "certificates", "achievements"),
}


@dataclass(frozen=True)
class ParsedResume:
    text: str
    metadata: dict[str, Any]


def read_resume(path: Path) -> str:
    """Backward-compatible text-only parser used by small unit tests and integrations."""
    return read_resume_with_metadata(path).text


def read_resume_with_metadata(path: Path, *, enable_ocr: bool = False, ocr_dpi: int = 200) -> ParsedResume:
    """Parse a resume with optional OCR fallback and lightweight section detection."""
    suffix = path.suffix.lower()
    parser_name = suffix.lstrip(".")
    ocr_used = False
    if suffix == ".pdf":
        from pypdf import PdfReader

        reader = PdfReader(str(path))
        text = "\n".join(page.extract_text() or "" for page in reader.pages)
    elif suffix == ".docx":
        from docx import Document

        document = Document(str(path))
        text = "\n".join(paragraph.text for paragraph in document.paragraphs)
    elif suffix == ".txt":
        text = path.read_text(encoding="utf-8", errors="replace")
    else:
        raise ValueError(f"Unsupported resume type: {suffix}")

    text = normalise_extracted_text(text)
    if len(text.strip()) < 30:
        if suffix != ".pdf" or not enable_ocr:
            raise ValueError("No usable text could be extracted")
        text = normalise_extracted_text(_ocr_pdf(path, dpi=ocr_dpi))
        ocr_used = True
    if len(text.strip()) < 30:
        raise ValueError("No usable text could be extracted, including the OCR fallback")
    return ParsedResume(
        text=text,
        metadata={
            "parser": parser_name,
            "ocr_enabled": enable_ocr,
            "ocr_used": ocr_used,
            "detected_sections": detect_sections(text),
        },
    )


def _ocr_pdf(path: Path, *, dpi: int) -> str:
    """OCR an image-only PDF only when the optional dependencies are installed."""
    try:
        import fitz  # PyMuPDF
        import pytesseract
        from PIL import Image
    except ImportError as exc:
        raise ValueError(
            "OCR fallback requires PyMuPDF, Pillow, and pytesseract; install requirements-optional.txt"
        ) from exc

    try:
        document = fitz.open(path)
        scale = max(1.0, dpi / 72)
        pages: list[str] = []
        for page in document:
            pixmap = page.get_pixmap(matrix=fitz.Matrix(scale, scale), alpha=False)
            image = Image.frombytes("RGB", (pixmap.width, pixmap.height), pixmap.samples)
            pages.append(pytesseract.image_to_string(image))
        return "\n".join(pages)
    except Exception as exc:
        raise ValueError(f"OCR fallback failed: {type(exc).__name__}: {exc}") from exc


def detect_sections(text: str) -> list[str]:
    """Return recognized sections without persisting the complete resume body in results."""
    found: list[str] = []
    for raw_line in text.splitlines():
        normalized = re.sub(r"[^a-z ]", " ", raw_line.lower())
        normalized = re.sub(r"\s+", " ", normalized).strip()
        if not normalized or len(normalized) > 48:
            continue
        for section, aliases in SECTION_HEADINGS.items():
            if section not in found and any(normalized == alias or normalized.startswith(f"{alias} ") for alias in aliases):
                found.append(section)
    return found


def _clean_line(line: str) -> str:
    return re.sub(r"\s+", " ", line).strip(" |,-")


def normalise_extracted_text(text: str) -> str:
    """Repair common PDF extraction where each character in a word is spaced out."""

    def collapse(match: re.Match[str]) -> str:
        return re.sub(r"\s+", "", match.group(0))

    # Each match is one word such as ``P y t h o n``; punctuation stays untouched.
    return re.sub(r"(?<!\w)(?:[A-Za-z]\s){2,}[A-Za-z](?!\w)", collapse, text)


def extract_name(text: str, fallback: str) -> str:
    """Use a conservative first-page name heuristic, with a stable file-name fallback."""
    blocked = re.compile(
        r"email|phone|github|linkedin|resume|curriculum|objective|summary|"
        r"education|experience|skills|projects|intern|software|engineer|@|http|"
        r"key achievements|growth path|web development|web deve|full stack|python backend|"
        r"computer networking|higher secondary|b\.?\s?tech|java backend|professional summary",
        re.I,
    )
    location_splitter = re.compile(
        r"\b(?:bengaluru|bangalore|hyderabad|ghaziabad|mumbai|delhi|pune|chennai|dehradun|india|remote)\b",
        re.I,
    )

    def contact_free(raw_line: str) -> str:
        line = raw_line.split("|")[0]
        line = re.sub(
            r"(?<=[a-z])(?=(?:bengaluru|bangalore|hyderabad|ghaziabad|mumbai|delhi|pune|chennai|dehradun)\b)",
            " ",
            line,
            flags=re.I,
        )
        line = re.split(
            r"(?:email|phone|mobile|github|linkedin)|https?://|@|\+?\d{5,}|[A-Z]:",
            line,
            maxsplit=1,
            flags=re.I,
        )[0]
        line = location_splitter.split(line, maxsplit=1)[0]
        return _clean_line(line)

    lines = [contact_free(raw_line) for raw_line in text.splitlines()[:80]]

    def name_from_line(index: int, line: str) -> str | None:
        attached_heading = re.fullmatch(r"([A-Z][A-Z.'-]+) ([A-Z])SKILLS", line)
        if attached_heading:
            return f"{attached_heading.group(1).title()} {attached_heading.group(2)}"
        # A first and last name broken across adjacent PDF text lines is common.
        if (
            re.fullmatch(r"[A-Za-z.'-]+", line)
            and index + 1 < len(lines)
            and re.fullmatch(r"[A-Za-z.'-]+", lines[index + 1])
        ):
            line = f"{line} {lines[index + 1]}"
        words = line.split()
        if (
            1 < len(words) <= 4
            and 3 <= len(line) <= 55
            and not blocked.search(line)
            and not re.search(r"\d", line)
            and all(re.match(r"^[A-Za-z.'-]+$", word) for word in words)
            and all(word[0].isupper() for word in words)
        ):
            return line.title() if line.isupper() else line
        return None

    # In a few layouts an all-caps name is immediately followed by the first
    # lower-case character of a fused email address.
    for raw_line in text.splitlines()[:30]:
        if "@" not in raw_line:
            continue
        raw_line = location_splitter.split(raw_line, maxsplit=1)[0]
        match = re.match(r"\s*([A-Z][A-Z ]{2,30})(?=[a-z0-9@])", raw_line)
        if match:
            line = _clean_line(match.group(1))
            words = line.split()
            if len(words) > 1 and not blocked.search(line):
                return line.title()

    # Names typically appear in the first text block. Check that block before
    # considering any later section headings.
    for index, line in enumerate(lines[:12]):
        if name := name_from_line(index, line):
            return name

    # A contact address can be fused directly to a title-case name by some PDF
    # exporters. Keep the clean opening prefix as a fallback.
    for raw_line in text.splitlines()[:12]:
        prefix = raw_line.split("|", maxsplit=1)[0].split("@", maxsplit=1)[0]
        prefix = location_splitter.split(prefix, maxsplit=1)[0]
        match = re.match(r"\s*([A-Z][a-z.'-]+(?:\s+[A-Z][a-z.'-]+){1,3})(?![A-Za-z0-9])", prefix)
        if match:
            line = _clean_line(match.group(1))
            if not blocked.search(line):
                return line

    # Accept a later all-caps candidate name, but not title-cased prose such as
    # "and an" or section headings.
    for index, line in enumerate(lines[12:], start=12):
        if line.isupper() and (name := name_from_line(index, line)):
            return name

    return fallback.replace("_", " ").replace("-", " ").title()


def extract_contacts(text: str) -> tuple[str | None, str | None]:
    email_match = EMAIL_RE.search(text)
    github_match = GITHUB_RE.search(text)
    email = email_match.group(0) if email_match else None
    github_url = None
    if github_match:
        github_url = f"https://github.com/{github_match.group(1)}"
    return email, github_url


def empty_failure(path: Path, error: Exception) -> CandidateResult:
    return CandidateResult(
        source_file=path.name,
        candidate_name=path.stem.replace("_", " ").title(),
        parsing_status="failed",
        extraction_error=str(error),
        rejection_reasons=["Resume could not be parsed; excluded from ranking."],
        concerns=["Unreadable or malformed resume."],
    )

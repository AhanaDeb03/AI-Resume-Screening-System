"""Configuration kept separate from screening business rules."""

from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Settings:
    github_token: str | None = os.getenv("GITHUB_TOKEN")
    github_timeout_seconds: float = float(os.getenv("GITHUB_TIMEOUT_SECONDS", "6"))
    github_cache_hours: int = int(os.getenv("GITHUB_CACHE_HOURS", "24"))
    max_network_workers: int = int(os.getenv("MAX_NETWORK_WORKERS", "6"))
    ocr_dpi: int = int(os.getenv("OCR_DPI", "200"))
    llm_api_key: str | None = os.getenv("LLM_API_KEY")
    llm_base_url: str = os.getenv("LLM_BASE_URL", "https://api.openai.com/v1")
    llm_model: str = os.getenv("LLM_MODEL", "gpt-4o-mini")


WEIGHTS = {
    "ai_project_depth": 40,
    "python_backend": 30,
    "cloud_fullstack": 15,
    "github": 10,
    "engineering_depth": 5,
}

SUPPORTED_SUFFIXES = {".pdf", ".docx", ".txt"}

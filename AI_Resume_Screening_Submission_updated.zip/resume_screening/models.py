"""Typed result objects used throughout the pipeline."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass
class Evidence:
    label: str
    snippet: str


@dataclass
class GitHubEnrichment:
    username: str | None = None
    status: str = "not_available"
    points: int = 0
    summary: str = "No GitHub profile found in the resume."
    error: str | None = None
    cached: bool = False


@dataclass
class CandidateResult:
    source_file: str
    candidate_name: str
    parsing_status: str = "parsed"
    extraction_error: str | None = None
    email: str | None = None
    github_url: str | None = None
    extraction: dict[str, Any] = field(default_factory=dict)
    matched_skills: list[str] = field(default_factory=list)
    eligibility_evidence: list[Evidence] = field(default_factory=list)
    eligible: bool = False
    rejection_reasons: list[str] = field(default_factory=list)
    score_breakdown: dict[str, int] = field(default_factory=dict)
    total_score: int = 0
    rank: int | None = None
    project_summary: str = ""
    strengths: list[str] = field(default_factory=list)
    concerns: list[str] = field(default_factory=list)
    project_evidence: list[Evidence] = field(default_factory=list)
    github: GitHubEnrichment = field(default_factory=GitHubEnrichment)
    llm_enrichment_status: str = "not_requested"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

"""Explainable, batch-safe resume screening package."""

__version__ = "1.0.0"

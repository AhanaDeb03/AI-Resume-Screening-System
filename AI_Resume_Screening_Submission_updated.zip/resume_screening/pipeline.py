"""Batch orchestration that keeps parsing, eligibility, scoring, and enrichment separate."""

from __future__ import annotations

import hashlib
from pathlib import Path

from .analysis import evaluate_candidate
from .config import SUPPORTED_SUFFIXES, Settings
from .github import GitHubEnricher
from .models import CandidateResult
from .parsers import empty_failure, extract_contacts, extract_name, read_resume_with_metadata


def screen_resumes(
    input_directory: Path,
    output_directory: Path,
    settings: Settings,
    *,
    skip_github: bool = False,
    enable_llm: bool = False,
    enable_ocr: bool = False,
) -> dict:
    paths = sorted(path for path in input_directory.rglob("*") if path.is_file() and path.suffix.lower() in SUPPORTED_SUFFIXES)
    candidates: list[CandidateResult] = []
    resume_texts: dict[str, str] = {}
    seen_hashes: dict[str, str] = {}
    duplicate_files: list[dict[str, str]] = []

    for path in paths:
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if digest in seen_hashes:
            duplicate_files.append({"duplicate": path.name, "original": seen_hashes[digest]})
            continue
        seen_hashes[digest] = path.name
        try:
            parsed_resume = read_resume_with_metadata(path, enable_ocr=enable_ocr, ocr_dpi=settings.ocr_dpi)
            text = parsed_resume.text
            email, github_url = extract_contacts(text)
            candidate = CandidateResult(
                source_file=path.name,
                candidate_name=extract_name(text, path.stem),
                email=email,
                github_url=github_url,
                extraction=parsed_resume.metadata,
            )
            candidates.append(evaluate_candidate(candidate, text))
            resume_texts[path.name] = text
        except Exception as exc:
            candidates.append(empty_failure(path, exc))

    if enable_llm:
        from .llm import StructuredLLMAdapter

        adapter = StructuredLLMAdapter(settings)
        for candidate in candidates:
            if candidate.eligible:
                adapter.enrich(candidate, resume_texts[candidate.source_file])

    if skip_github:
        for candidate in candidates:
            candidate.github.status = "skipped"
            candidate.github.summary = "GitHub enrichment skipped by CLI option."
    else:
        GitHubEnricher(settings, output_directory / ".cache" / "github.json").enrich(candidates)

    for candidate in candidates:
        if candidate.eligible:
            candidate.score_breakdown["github"] = candidate.github.points
            candidate.total_score = max(0, sum(candidate.score_breakdown.values()))
        else:
            candidate.total_score = 0

    eligible = sorted(
        (candidate for candidate in candidates if candidate.eligible),
        key=lambda item: (-item.total_score, item.candidate_name.lower(), item.source_file),
    )
    for rank, candidate in enumerate(eligible, start=1):
        candidate.rank = rank

    failed = [candidate for candidate in candidates if candidate.parsing_status == "failed"]
    rejected = [candidate for candidate in candidates if not candidate.eligible and candidate.parsing_status != "failed"]
    return {
        "schema_version": "1.0",
        "scoring_weights": {
            "ai_project_depth": 40,
            "python_backend": 30,
            "cloud_fullstack": 15,
            "github": 10,
            "engineering_depth": 5,
        },
        "batch_summary": {
            "total_resume_files": len(paths),
            "unique_resume_files": len(candidates),
            "successfully_parsed": len(candidates) - len(failed),
            "eligible": len(eligible),
            "rejected": len(rejected),
            "failed_unreadable": len(failed),
            "duplicates_skipped": len(duplicate_files),
        },
        "duplicates_skipped": duplicate_files,
        "ranked_eligible_candidates": [candidate.to_dict() for candidate in eligible],
        "rejected_candidates": [candidate.to_dict() for candidate in rejected],
        "failed_candidates": [candidate.to_dict() for candidate in failed],
        "all_candidates": [candidate.to_dict() for candidate in candidates],
    }

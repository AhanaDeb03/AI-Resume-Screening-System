"""Generate a small, dependency-free static HTML insights report."""

from __future__ import annotations

import json
from pathlib import Path


def write_html_report(result: dict, destination: Path) -> None:
    """Write a portable report that reads only the generated result payload."""
    destination.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(result, ensure_ascii=False).replace("<", "\\u003c").replace("&", "\\u0026")
    destination.write_text(_page(payload), encoding="utf-8")


def _page(payload: str) -> str:
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Resume Screening Insights</title>
  <style>
    :root {{ color-scheme: light; --ink:#172033; --muted:#5d6b82; --line:#d9e1ec; --panel:#fff; --wash:#f4f7fb; --blue:#2357c6; --green:#087443; --red:#b42318; --amber:#ad6500; }}
    * {{ box-sizing:border-box; }}
    body {{ margin:0; background:var(--wash); color:var(--ink); font:15px/1.45 Inter,system-ui,-apple-system,"Segoe UI",sans-serif; }}
    main {{ max-width:1280px; margin:auto; padding:36px 22px 64px; }}
    h1 {{ margin:0; font-size:30px; letter-spacing:-.03em; }} h2 {{ margin:32px 0 12px; font-size:19px; }}
    .sub {{ color:var(--muted); margin:6px 0 0; }}
    .cards {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(150px,1fr)); gap:12px; margin:24px 0; }}
    .card,.panel {{ background:var(--panel); border:1px solid var(--line); border-radius:12px; box-shadow:0 1px 2px #17203308; }}
    .card {{ padding:16px; }} .card b {{ display:block; font-size:28px; line-height:1.1; }} .card span {{ color:var(--muted); font-size:13px; }}
    .panel {{ overflow:hidden; }} .toolbar {{ display:flex; gap:10px; padding:14px; border-bottom:1px solid var(--line); flex-wrap:wrap; }}
    input,select {{ border:1px solid var(--line); border-radius:7px; padding:8px 10px; font:inherit; background:#fff; }} input {{ min-width:250px; flex:1; }}
    table {{ width:100%; border-collapse:collapse; }} th,td {{ padding:12px 14px; text-align:left; border-bottom:1px solid var(--line); vertical-align:top; }} th {{ color:var(--muted); font-size:12px; letter-spacing:.04em; text-transform:uppercase; background:#fafcff; }}
    tr:last-child td {{ border-bottom:0; }} .score {{ font-weight:700; color:var(--blue); }} .muted {{ color:var(--muted); }}
    .badge {{ display:inline-block; border-radius:999px; padding:2px 8px; font-size:12px; font-weight:650; white-space:nowrap; }} .eligible {{ background:#dff7ea; color:var(--green); }} .rejected {{ background:#fee9e7; color:var(--red); }} .failed {{ background:#fff1d6; color:var(--amber); }}
    .tags {{ display:flex; flex-wrap:wrap; gap:4px; }} .tag {{ background:#eaf0ff; color:#244ca4; padding:2px 7px; border-radius:999px; font-size:12px; }}
    details {{ margin-top:6px; }} summary {{ cursor:pointer; color:var(--blue); font-weight:600; }} .evidence {{ margin:7px 0 0; color:var(--muted); font-size:13px; }}
    .empty {{ padding:28px; color:var(--muted); text-align:center; }} @media(max-width:720px) {{ main {{ padding:24px 12px; }} th:nth-child(4),td:nth-child(4) {{ display:none; }} }}
  </style>
</head>
<body>
  <main>
    <header><h1>Resume Screening Insights</h1><p class="sub" id="caption"></p></header>
    <section class="cards" id="cards"></section>
    <h2>Ranked candidates</h2>
    <section class="panel">
      <div class="toolbar"><input id="query" type="search" placeholder="Filter by name, skill, or evidence"><select id="status"><option value="all">All statuses</option><option value="eligible">Eligible</option><option value="rejected">Rejected</option></select></div>
      <div id="table"></div>
    </section>
  </main>
  <script id="screening-data" type="application/json">{payload}</script>
  <script>
    const data = JSON.parse(document.getElementById('screening-data').textContent);
    const summary = data.batch_summary;
    const all = data.all_candidates || [];
    const text = value => String(value ?? '');
    const escape = value => text(value).replace(/[&<>'"]/g, char => ({{'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}}[char]));
    const chips = values => (values || []).map(value => `<span class="tag">${{escape(value)}}</span>`).join('');
    document.getElementById('caption').textContent = `Generated from ${{summary.total_resume_files}} resume files; static report, no candidate data leaves this page.`;
    const cardData = [['Eligible',summary.eligible],['Rejected',summary.rejected],['Parsed',summary.successfully_parsed],['Unreadable',summary.failed_unreadable],['Duplicates',summary.duplicates_skipped]];
    document.getElementById('cards').innerHTML = cardData.map(([label,value]) => `<div class="card"><b>${{value}}</b><span>${{label}}</span></div>`).join('');
    const getStatus = candidate => candidate.parsing_status === 'failed' ? 'failed' : candidate.eligible ? 'eligible' : 'rejected';
    const detail = candidate => {{
      const evidence = [...(candidate.eligibility_evidence || []), ...(candidate.project_evidence || [])].slice(0,3);
      const notes = candidate.eligible ? (candidate.concerns || []) : (candidate.rejection_reasons || []);
      const github = candidate.github || {{}};
      const extraction = candidate.extraction || {{}};
      return `<details><summary>Evidence and insights</summary>
        <div class="evidence"><b>Project:</b> ${{escape(candidate.project_summary || 'No project summary available.')}}</div>
        <div class="evidence"><b>GitHub:</b> ${{escape(github.summary || 'Not available')}}</div>
        <div class="evidence"><b>Extraction:</b> ${{escape(extraction.parser || 'unknown parser')}}; sections: ${{escape((extraction.detected_sections || []).join(', ') || 'not detected')}}</div>
        ${{evidence.map(item => `<div class="evidence"><b>${{escape(item.label)}}:</b> ${{escape(item.snippet)}}</div>`).join('')}}
        ${{notes.length ? `<div class="evidence"><b>Notes:</b> ${{escape(notes.join(' • '))}}</div>` : ''}}
      </details>`;
    }};
    function render() {{
      const needle = document.getElementById('query').value.trim().toLowerCase();
      const wanted = document.getElementById('status').value;
      const rows = all.filter(candidate => {{
        const candidateStatus = getStatus(candidate);
        const haystack = [candidate.candidate_name, ...(candidate.matched_skills || []), candidate.project_summary, ...(candidate.rejection_reasons || [])].join(' ').toLowerCase();
        return (wanted === 'all' || wanted === candidateStatus) && (!needle || haystack.includes(needle));
      }}).sort((a,b) => (a.rank || 9999) - (b.rank || 9999) || b.total_score - a.total_score);
      if (!rows.length) {{ document.getElementById('table').innerHTML = '<div class="empty">No candidates match this filter.</div>'; return; }}
      document.getElementById('table').innerHTML = `<table><thead><tr><th>Rank</th><th>Candidate</th><th>Status</th><th>Score</th><th>Skills and insights</th></tr></thead><tbody>${{rows.map(candidate => {{
        const state = getStatus(candidate);
        return `<tr><td>${{candidate.rank || '—'}}</td><td><b>${{escape(candidate.candidate_name)}}</b><br><span class="muted">${{escape(candidate.source_file)}}</span></td><td><span class="badge ${{state}}">${{state}}</span></td><td class="score">${{candidate.eligible ? `${{candidate.total_score}} / 100` : '—'}}</td><td><div class="tags">${{chips(candidate.matched_skills)}}</div>${{detail(candidate)}}</td></tr>`;
      }}).join('')}}</tbody></table>`;
    }}
    document.getElementById('query').addEventListener('input', render); document.getElementById('status').addEventListener('change', render); render();
  </script>
</body>
</html>"""

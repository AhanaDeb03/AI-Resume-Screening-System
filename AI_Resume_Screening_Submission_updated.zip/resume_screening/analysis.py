"""Deterministic eligibility, evidence collection, and score rules."""

from __future__ import annotations

import re
from collections.abc import Iterable

from .config import WEIGHTS
from .models import CandidateResult, Evidence


SKILL_PATTERNS: dict[str, tuple[str, ...]] = {
    "Python": (r"\bpython\b",),
    "FastAPI": (r"\bfastapi\b",),
    "Django": (r"\bdjango\b",),
    "Flask": (r"\bflask\b",),
    "Async": (r"\basync(?:io|hronous)?\b",),
    "PostgreSQL": (r"\bpostgre(?:sql|s)\b",),
    "Redis": (r"\bredis\b",),
    "Docker": (r"\bdocker\b",),
    "Kubernetes": (r"\bkubernetes|\bk8s\b",),
    "GCP": (r"\bgcp\b|google cloud",),
    "AWS": (r"\baws\b|amazon web services",),
    "React": (r"\breact(?:\.js)?\b",),
    "Next.js": (r"\bnext\.?(?:js)?\b",),
    "LangChain": (r"\blangchain\b",),
    "LangGraph": (r"\blanggraph\b",),
    "LlamaIndex": (r"\bllamaindex\b",),
    "Google ADK": (r"\bgoogle adk\b|\bagents development kit\b",),
    "RAG": (r"\brag\b|retrieval[- ]augmented",),
    "LLM": (r"\bllm(?:s)?\b|large language model",),
    "Vector Search": (r"vector (?:db|database|search|store)|\bfaiss\b|\bpinecone\b|\bweaviate\b|\bchroma(?:db)?\b",),
    "Embeddings": (r"\bembeddings?\b",),
    "Agentic Workflows": (r"\bagent(?:ic|s)?\b|multi[- ]agent|tool[- ]calling",),
    "Machine Learning": (r"\bmachine learning\b|\bdeep learning\b|\bpytorch\b|\btensorflow\b",),
    "Testing": (r"\bpytest\b|\bunit tests?\b|\bintegration tests?\b|\btesting\b",),
}

AI_FEATURES: dict[str, tuple[str, ...]] = {
    "agentic workflow": (r"\bagent(?:ic|s)?\b", r"multi[- ]agent", r"langgraph", r"tool[- ]calling"),
    "retrieval or RAG": (r"\brag\b", r"retrieval[- ]augmented", r"retrieval pipeline"),
    "embeddings or vector search": (r"\bembeddings?\b", r"vector (?:db|database|search|store)", r"\bfaiss\b", r"\bpinecone\b", r"\bchroma"),
    "tool integration": (r"tool[- ]calling", r"function calling", r"api integration", r"external tools?"),
    "state or orchestration": (r"\bstate(?:ful| management)?\b", r"orchestrat", r"workflow"),
    "evaluation or observability": (r"\bevaluat", r"hallucination", r"tracing", r"observability"),
    "model or data pipeline": (r"fine[- ]?tun", r"data pipeline", r"classification", r"training", r"inference"),
}

PROJECT_CONTEXT = re.compile(
    r"\b(project|built|developed|created|implemented|designed|deployed|system|"
    r"pipeline|application|assistant|platform|workflow|internship|experience)\b",
    re.I,
)
THIN_WRAPPER_CUES = re.compile(
    r"\b(thin wrapper|wrapper around|api[- ]?only|simple api call|openai api call|gemini api call)\b",
    re.I,
)
TUTORIAL_CUES = re.compile(r"\b(tutorial|udemy|course clone|youtube clone|followed a course)\b", re.I)


def _compact(value: str, limit: int = 240) -> str:
    value = re.sub(r"\s+", " ", value).strip()
    return value[: limit - 3] + "..." if len(value) > limit else value


def _first_evidence(text: str, patterns: Iterable[str], label: str) -> Evidence | None:
    for pattern in patterns:
        match = re.search(pattern, text, re.I)
        if match:
            start = max(0, match.start() - 100)
            end = min(len(text), match.end() + 160)
            return Evidence(label=label, snippet=_compact(text[start:end]))
    return None


def _has_any(text: str, patterns: Iterable[str]) -> bool:
    return any(re.search(pattern, text, re.I) for pattern in patterns)


def matched_skills(text: str) -> list[str]:
    return [name for name, patterns in SKILL_PATTERNS.items() if _has_any(text, patterns)]


def _ai_features(text: str) -> list[str]:
    return [feature for feature, patterns in AI_FEATURES.items() if _has_any(text, patterns)]


def evaluate_candidate(candidate: CandidateResult, text: str) -> CandidateResult:
    """Apply the hard filters first, then calculate non-GitHub score components."""
    candidate.matched_skills = matched_skills(text)
    python_evidence = _first_evidence(text, SKILL_PATTERNS["Python"], "Python evidence")
    ai_patterns = tuple(pattern for patterns in AI_FEATURES.values() for pattern in patterns) + (
        r"\blangchain\b",
        r"\bllamaindex\b",
        r"\bgoogle adk\b",
        r"\bllm(?:s)?\b",
    )
    ai_evidence = _first_evidence(text, ai_patterns, "AI or agentic evidence")
    candidate.eligibility_evidence = [item for item in (python_evidence, ai_evidence) if item]

    if not python_evidence:
        candidate.rejection_reasons.append("No evidence of Python as a skill, project technology, or implementation language.")
    if not ai_evidence:
        candidate.rejection_reasons.append(
            "No meaningful AI, LLM, RAG, agentic, retrieval, or equivalent implementation evidence."
        )
    candidate.eligible = not candidate.rejection_reasons
    if not candidate.eligible:
        candidate.concerns = list(candidate.rejection_reasons)
        return candidate

    features = _ai_features(text)
    project_context = bool(PROJECT_CONTEXT.search(text))
    candidate.project_evidence = [
        evidence
        for feature, patterns in AI_FEATURES.items()
        if (evidence := _first_evidence(text, patterns, feature)) is not None
    ]
    candidate.score_breakdown = _score(text, features, project_context)
    candidate.total_score = sum(candidate.score_breakdown.values())
    candidate.project_summary = _project_summary(features, project_context)
    candidate.strengths = _strengths(candidate.score_breakdown, features)
    candidate.concerns = _concerns(candidate.score_breakdown, features, project_context)
    return candidate


def _score(text: str, ai_features: list[str], project_context: bool) -> dict[str, int]:
    # AI points favor implementation detail; a skills-only framework mention stays low.
    if project_context:
        ai_score = min(WEIGHTS["ai_project_depth"], 8 + 6 * len(ai_features))
    else:
        ai_score = min(8, 3 * len(ai_features))

    python_score = 10
    if _has_any(text, SKILL_PATTERNS["FastAPI"]):
        python_score += 6
    if _has_any(text, SKILL_PATTERNS["Django"] + SKILL_PATTERNS["Flask"]):
        python_score += 3
    if _has_any(text, SKILL_PATTERNS["Async"]):
        python_score += 4
    if _has_any(text, SKILL_PATTERNS["PostgreSQL"]):
        python_score += 4
    if _has_any(text, SKILL_PATTERNS["Redis"]):
        python_score += 3
    python_score = min(WEIGHTS["python_backend"], python_score)

    cloud_score = 0
    if _has_any(text, SKILL_PATTERNS["GCP"] + SKILL_PATTERNS["AWS"]):
        cloud_score += 5
    if _has_any(text, SKILL_PATTERNS["Docker"]):
        cloud_score += 4
    if _has_any(text, SKILL_PATTERNS["Kubernetes"]):
        cloud_score += 2
    if re.search(r"\b(deploy|deployment|ci/cd|github actions)\b", text, re.I):
        cloud_score += 2
    if _has_any(text, SKILL_PATTERNS["React"] + SKILL_PATTERNS["Next.js"]):
        cloud_score += 2
    cloud_score = min(WEIGHTS["cloud_fullstack"], cloud_score)

    engineering_score = 0
    if _has_any(text, SKILL_PATTERNS["Testing"]):
        engineering_score += 2
    if re.search(r"\b(caching|queue|celery|rabbitmq|kafka|architecture|microservice|concurrency|retry|failure handling|monitoring)\b", text, re.I):
        engineering_score += 3
    engineering_score = min(WEIGHTS["engineering_depth"], engineering_score)

    penalty = 0
    if THIN_WRAPPER_CUES.search(text) and len(ai_features) < 2:
        penalty -= 10
    elif THIN_WRAPPER_CUES.search(text):
        penalty -= 5
    if TUTORIAL_CUES.search(text):
        penalty -= 7

    return {
        "ai_project_depth": ai_score,
        "python_backend": python_score,
        "cloud_fullstack": cloud_score,
        "github": 0,
        "engineering_depth": engineering_score,
        "project_quality_penalty": penalty,
    }


def _project_summary(features: list[str], has_context: bool) -> str:
    if not features:
        return "AI evidence is present but implementation depth is limited in the extracted text."
    prefix = "Project evidence includes" if has_context else "AI framework or technology evidence includes"
    return f"{prefix}: {', '.join(features[:4])}."


def _strengths(scores: dict[str, int], features: list[str]) -> list[str]:
    strengths: list[str] = []
    if scores["ai_project_depth"] >= 26:
        strengths.append("Detailed AI or agentic project evidence")
    elif features:
        strengths.append("Relevant AI or LLM exposure")
    if scores["python_backend"] >= 20:
        strengths.append("Strong Python and backend evidence")
    if scores["cloud_fullstack"] >= 8:
        strengths.append("Deployment or full-stack delivery evidence")
    if scores["engineering_depth"] >= 3:
        strengths.append("Non-trivial engineering reliability signals")
    return strengths or ["Meets the minimum Python and AI evidence threshold"]


def _concerns(scores: dict[str, int], features: list[str], has_context: bool) -> list[str]:
    concerns: list[str] = []
    if not has_context or scores["ai_project_depth"] <= 8:
        concerns.append("AI evidence has limited project implementation detail.")
    if scores["python_backend"] < 16:
        concerns.append("Limited backend-specific Python evidence beyond the base language signal.")
    if scores["project_quality_penalty"] < 0:
        concerns.append("Project-quality penalty applied for thin-wrapper or tutorial-style signals.")
    return concerns

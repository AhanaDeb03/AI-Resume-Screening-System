"""Optional structured LLM enrichment, deliberately isolated from hard filters."""

from __future__ import annotations

import json
from urllib.request import Request, urlopen

from pydantic import BaseModel, Field

from .config import Settings
from .models import CandidateResult


class ResumeInsights(BaseModel):
    project_summary: str = Field(max_length=500)
    strengths: list[str] = Field(default_factory=list, max_length=4)
    concerns: list[str] = Field(default_factory=list, max_length=4)
    evidence: list[str] = Field(default_factory=list, max_length=4)


class StructuredLLMAdapter:
    """OpenAI-compatible JSON-mode adapter; failures leave deterministic results intact."""

    def __init__(self, settings: Settings) -> None:
        if not settings.llm_api_key:
            raise ValueError("LLM_API_KEY is required when --enable-llm is used")
        self.settings = settings

    def enrich(self, candidate: CandidateResult, text: str) -> None:
        schema = ResumeInsights.model_json_schema()
        prompt = (
            "Analyze this candidate resume only for an SDE intern role with Python and practical AI/agentic work. "
            "Do not decide hard eligibility. Return concise, evidence-backed JSON that matches this schema: "
            f"{json.dumps(schema)}\n\nRESUME:\n{text[:18000]}"
        )
        payload = {
            "model": self.settings.llm_model,
            "response_format": {"type": "json_object"},
            "messages": [
                {"role": "system", "content": "Return JSON only. Do not invent resume evidence."},
                {"role": "user", "content": prompt},
            ],
        }
        request = Request(
            self.settings.llm_base_url.rstrip("/") + "/chat/completions",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Authorization": f"Bearer {self.settings.llm_api_key}", "Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urlopen(request, timeout=20) as response:
                response_data = json.load(response)
            content = response_data["choices"][0]["message"]["content"]
            insights = ResumeInsights.model_validate_json(content)
            candidate.project_summary = insights.project_summary or candidate.project_summary
            candidate.strengths = insights.strengths or candidate.strengths
            candidate.concerns = insights.concerns or candidate.concerns
            candidate.llm_enrichment_status = "enriched"
        except Exception as exc:  # Model calls must not fail a resume or batch.
            candidate.llm_enrichment_status = f"failed: {type(exc).__name__}"

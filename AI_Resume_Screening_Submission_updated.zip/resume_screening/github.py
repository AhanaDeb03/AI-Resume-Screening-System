"""Bounded, cached public GitHub enrichment with failure isolation."""

from __future__ import annotations

import json
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Iterable
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from .config import Settings
from .models import CandidateResult, GitHubEnrichment


class GitHubEnricher:
    def __init__(self, settings: Settings, cache_path: Path) -> None:
        self.settings = settings
        self.cache_path = cache_path
        self.cache = self._load_cache()

    @staticmethod
    def username_from_url(url: str | None) -> str | None:
        if not url:
            return None
        match = re.search(r"github\.com/([A-Za-z0-9-]+)", url, re.I)
        return match.group(1) if match else None

    def enrich(self, candidates: Iterable[CandidateResult]) -> None:
        by_username: dict[str, list[CandidateResult]] = {}
        for candidate in candidates:
            username = self.username_from_url(candidate.github_url)
            if username:
                by_username.setdefault(username.lower(), []).append(candidate)
            else:
                candidate.github = GitHubEnrichment(status="not_available")

        with ThreadPoolExecutor(max_workers=max(1, self.settings.max_network_workers)) as executor:
            futures = {executor.submit(self._for_username, username): username for username in by_username}
            for future in as_completed(futures):
                username = futures[future]
                try:
                    result = future.result()
                except Exception as exc:  # Defensive: enrichment may never end the batch.
                    result = GitHubEnrichment(
                        username=username,
                        status="failed",
                        summary="GitHub enrichment failed; score left unchanged.",
                        error=str(exc),
                    )
                for candidate in by_username[username]:
                    candidate.github = result
        self._save_cache()

    def _for_username(self, username: str) -> GitHubEnrichment:
        cached = self.cache.get(username)
        if cached and self._cache_is_fresh(cached):
            cached_value = {**cached["value"], "cached": True}
            return GitHubEnrichment(**cached_value)
        result = self._fetch(username)
        if result.status == "enriched":
            self.cache[username] = {"retrieved_at": datetime.now(UTC).isoformat(), "value": result.__dict__}
        return result

    def _fetch(self, username: str) -> GitHubEnrichment:
        """Prefer one authenticated GraphQL request; retain a public REST fallback."""
        if self.settings.github_token:
            graphql_result = self._fetch_graphql(username)
            if graphql_result.status == "enriched":
                return graphql_result
        return self._fetch_events(username)

    def _fetch_graphql(self, username: str) -> GitHubEnrichment:
        query = """
        query ResumeScreening($login: String!) {
          user(login: $login) {
            repositories(first: 30, privacy: PUBLIC, orderBy: {field: PUSHED_AT, direction: DESC}) {
              totalCount
              nodes { name pushedAt stargazerCount primaryLanguage { name } languages(first: 8) { nodes { name } } }
            }
          }
        }
        """
        body = json.dumps({"query": query, "variables": {"login": username}}).encode("utf-8")
        request = Request(
            "https://api.github.com/graphql",
            data=body,
            headers={
                "Accept": "application/vnd.github+json",
                "Authorization": f"Bearer {self.settings.github_token}",
                "Content-Type": "application/json",
                "User-Agent": "resume-screening-assignment",
            },
            method="POST",
        )
        try:
            with urlopen(request, timeout=self.settings.github_timeout_seconds) as response:
                payload = json.load(response)
            user = payload.get("data", {}).get("user")
            if not user:
                message = "; ".join(error.get("message", "unknown GraphQL error") for error in payload.get("errors", []))
                raise ValueError(message or "GitHub user not found")
            repository_data = user["repositories"]
            repositories = repository_data.get("nodes", [])
        except HTTPError as exc:
            return GitHubEnrichment(username=username, status="failed", summary="GitHub GraphQL request failed.", error=f"HTTP {exc.code}")
        except (URLError, TimeoutError, ValueError, OSError, KeyError) as exc:
            return GitHubEnrichment(username=username, status="failed", summary="GitHub GraphQL enrichment unavailable.", error=str(exc))

        dates = [self._parse_date(repo.get("pushedAt")) for repo in repositories]
        valid_dates = [value for value in dates if value]
        most_recent = max(valid_dates) if valid_dates else None
        activity_points = self._activity_points_from_date(most_recent)
        relevant_repositories = []
        maintained = 0
        for repo in repositories:
            languages = {node.get("name", "").lower() for node in repo.get("languages", {}).get("nodes", [])}
            primary = (repo.get("primaryLanguage") or {}).get("name", "").lower()
            name = repo.get("name", "")
            pushed_at = self._parse_date(repo.get("pushedAt"))
            if pushed_at and datetime.now(UTC) - pushed_at <= timedelta(days=365):
                maintained += 1
            if {"python", "jupyter notebook"} & languages or primary in {"python", "jupyter notebook"} or re.search(r"ai|llm|rag|agent|ml|data", name, re.I):
                relevant_repositories.append(name)
        if relevant_repositories:
            repository_points = 5
        elif maintained >= 5:
            repository_points = 4
        elif maintained >= 2:
            repository_points = 2
        else:
            repository_points = 1 if repositories else 0
        recency = f"most recent repository push {most_recent.date().isoformat()}" if most_recent else "no visible push dates"
        return GitHubEnrichment(
            username=username,
            status="enriched",
            points=min(10, activity_points + repository_points),
            summary=(
                f"Authenticated GraphQL: {repository_data.get('totalCount', len(repositories))} public repositories, "
                f"{maintained} updated in the last year, {len(relevant_repositories)} Python/AI-relevant; {recency}."
            ),
        )

    def _fetch_events(self, username: str) -> GitHubEnrichment:
        url = f"https://api.github.com/users/{username}/events/public?per_page=30"
        headers = {
            "Accept": "application/vnd.github+json",
            "User-Agent": "resume-screening-assignment",
        }
        if self.settings.github_token:
            headers["Authorization"] = f"Bearer {self.settings.github_token}"
        try:
            request = Request(url, headers=headers)
            with urlopen(request, timeout=self.settings.github_timeout_seconds) as response:
                events = json.load(response)
            if not isinstance(events, list):
                raise ValueError("Unexpected GitHub API response")
        except HTTPError as exc:
            return GitHubEnrichment(
                username=username,
                status="failed",
                summary="GitHub API request failed; score left unchanged.",
                error=f"HTTP {exc.code}",
            )
        except (URLError, TimeoutError, ValueError, OSError) as exc:
            return GitHubEnrichment(
                username=username,
                status="failed",
                summary="GitHub enrichment unavailable; score left unchanged.",
                error=str(exc),
            )

        activity_points, most_recent = self._activity_score(events)
        repo_names = {event.get("repo", {}).get("name", "") for event in events}
        repo_names.discard("")
        relevant = [name for name in repo_names if re.search(r"python|ai|llm|rag|agent|ml|data", name, re.I)]
        if relevant:
            repository_points = 5
        elif len(repo_names) >= 5:
            repository_points = 4
        elif len(repo_names) >= 2:
            repository_points = 2
        else:
            repository_points = 1 if repo_names else 0
        total = min(10, activity_points + repository_points)
        recency = f"most recent event {most_recent.date().isoformat()}" if most_recent else "no dated public events"
        relevance = f"{len(relevant)} relevant-looking repository name(s)" if relevant else "no AI/Python repository name signal"
        return GitHubEnrichment(
            username=username,
            status="enriched",
            points=total,
            summary=(
                f"{len(events)} recent public event(s), {len(repo_names)} repository name(s) visible in those events; "
                f"{recency}; {relevance}."
            ),
        )

    @staticmethod
    def _activity_score(events: list[dict]) -> tuple[int, datetime | None]:
        timestamps: list[datetime] = []
        for event in events:
            value = event.get("created_at")
            if not value:
                continue
            try:
                timestamps.append(datetime.fromisoformat(value.replace("Z", "+00:00")))
            except ValueError:
                continue
        if not timestamps:
            return 0, None
        most_recent = max(timestamps)
        return GitHubEnricher._activity_points_from_date(most_recent), most_recent

    @staticmethod
    def _activity_points_from_date(most_recent: datetime | None) -> int:
        if not most_recent:
            return 0
        age = datetime.now(UTC) - most_recent
        if age <= timedelta(days=14):
            return 5
        elif age <= timedelta(days=45):
            return 4
        elif age <= timedelta(days=90):
            return 3
        elif age <= timedelta(days=180):
            return 2
        elif age <= timedelta(days=365):
            return 1
        return 0

    @staticmethod
    def _parse_date(value: str | None) -> datetime | None:
        if not value:
            return None
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            return None

    def _load_cache(self) -> dict:
        try:
            return json.loads(self.cache_path.read_text(encoding="utf-8"))
        except (FileNotFoundError, json.JSONDecodeError):
            return {}

    def _save_cache(self) -> None:
        self.cache_path.parent.mkdir(parents=True, exist_ok=True)
        self.cache_path.write_text(json.dumps(self.cache, indent=2), encoding="utf-8")

    def _cache_is_fresh(self, entry: dict) -> bool:
        try:
            retrieved = datetime.fromisoformat(entry["retrieved_at"])
            return datetime.now(UTC) - retrieved < timedelta(hours=self.settings.github_cache_hours)
        except (KeyError, TypeError, ValueError):
            return False

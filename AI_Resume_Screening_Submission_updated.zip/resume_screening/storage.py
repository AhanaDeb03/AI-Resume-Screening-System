"""Small SQLite persistence layer for screening runs and reviewer overrides."""

from __future__ import annotations

import copy
import json
import sqlite3
from contextlib import closing
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

VALID_DECISIONS = {"approve", "reject", "needs_review"}


class ScreeningStore:
    def __init__(self, database_path: Path) -> None:
        self.database_path = database_path
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self._initialise()

    def _connection(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.database_path)
        connection.row_factory = sqlite3.Row
        return connection

    def _initialise(self) -> None:
        with closing(self._connection()) as connection, connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS screening_runs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    input_directory TEXT NOT NULL,
                    result_json TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS reviewer_overrides (
                    source_file TEXT PRIMARY KEY,
                    decision TEXT NOT NULL,
                    notes TEXT NOT NULL DEFAULT '',
                    score_override INTEGER,
                    updated_at TEXT NOT NULL
                );
                """
            )

    def save_run(self, result: dict[str, Any], input_directory: str) -> int:
        with closing(self._connection()) as connection, connection:
            cursor = connection.execute(
                "INSERT INTO screening_runs (created_at, input_directory, result_json) VALUES (?, ?, ?)",
                (datetime.now(UTC).isoformat(), input_directory, json.dumps(result, ensure_ascii=False)),
            )
            return int(cursor.lastrowid)

    def latest_result(self) -> tuple[int, dict[str, Any]] | None:
        with closing(self._connection()) as connection:
            row = connection.execute("SELECT id, result_json FROM screening_runs ORDER BY id DESC LIMIT 1").fetchone()
        return (int(row["id"]), json.loads(row["result_json"])) if row else None

    def result_for_run(self, run_id: int) -> dict[str, Any] | None:
        with closing(self._connection()) as connection:
            row = connection.execute("SELECT result_json FROM screening_runs WHERE id = ?", (run_id,)).fetchone()
        return json.loads(row["result_json"]) if row else None

    def save_review(self, source_file: str, decision: str, notes: str = "", score_override: int | None = None) -> dict[str, Any]:
        if decision not in VALID_DECISIONS:
            raise ValueError(f"decision must be one of: {', '.join(sorted(VALID_DECISIONS))}")
        if score_override is not None and not 0 <= score_override <= 100:
            raise ValueError("score_override must be between 0 and 100")
        review = {
            "decision": decision,
            "notes": notes.strip(),
            "score_override": score_override,
            "updated_at": datetime.now(UTC).isoformat(),
        }
        with closing(self._connection()) as connection, connection:
            connection.execute(
                """
                INSERT INTO reviewer_overrides (source_file, decision, notes, score_override, updated_at)
                VALUES (:source_file, :decision, :notes, :score_override, :updated_at)
                ON CONFLICT(source_file) DO UPDATE SET
                  decision=excluded.decision, notes=excluded.notes,
                  score_override=excluded.score_override, updated_at=excluded.updated_at
                """,
                {"source_file": source_file, **review},
            )
        return review

    def reviews(self) -> dict[str, dict[str, Any]]:
        with closing(self._connection()) as connection:
            rows = connection.execute("SELECT source_file, decision, notes, score_override, updated_at FROM reviewer_overrides").fetchall()
        return {row["source_file"]: dict(row) for row in rows}

    def apply_reviews(self, result: dict[str, Any]) -> dict[str, Any]:
        """Apply persistent human decisions to a copy and rebuild result lists/ranks."""
        updated = copy.deepcopy(result)
        reviews = self.reviews()
        candidates = updated.get("all_candidates", [])
        applied = 0
        for candidate in candidates:
            review = reviews.get(candidate["source_file"])
            if not review:
                continue
            candidate["review"] = {key: value for key, value in review.items() if key != "source_file"}
            applied += 1
            if candidate.get("parsing_status") == "failed":
                continue
            if review["decision"] == "approve":
                candidate["eligible"] = True
                candidate["rejection_reasons"] = []
                candidate["concerns"] = [*candidate.get("concerns", []), "Eligibility approved by reviewer."]
            elif review["decision"] == "reject":
                candidate["eligible"] = False
                candidate["rank"] = None
                candidate["total_score"] = 0
                candidate["rejection_reasons"] = ["Rejected by reviewer."]
            if review["score_override"] is not None and candidate.get("eligible"):
                candidate["total_score"] = review["score_override"]
                candidate.setdefault("score_breakdown", {})["reviewer_score_override"] = review["score_override"]

        eligible = sorted(
            (candidate for candidate in candidates if candidate.get("eligible")),
            key=lambda candidate: (-candidate.get("total_score", 0), candidate.get("candidate_name", "").lower(), candidate["source_file"]),
        )
        for rank, candidate in enumerate(eligible, start=1):
            candidate["rank"] = rank
        rejected = [candidate for candidate in candidates if not candidate.get("eligible") and candidate.get("parsing_status") != "failed"]
        failed = [candidate for candidate in candidates if candidate.get("parsing_status") == "failed"]
        updated["ranked_eligible_candidates"] = eligible
        updated["rejected_candidates"] = rejected
        updated["failed_candidates"] = failed
        updated["batch_summary"].update({"eligible": len(eligible), "rejected": len(rejected), "failed_unreadable": len(failed)})
        updated["review_overrides_applied"] = applied
        return updated

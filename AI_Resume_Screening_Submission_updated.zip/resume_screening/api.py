"""Optional FastAPI wrapper around the screening pipeline and reviewer store."""

from __future__ import annotations

from pathlib import Path

from pydantic import BaseModel, Field

from .config import Settings
from .pipeline import screen_resumes
from .storage import ScreeningStore


class ScreenRequest(BaseModel):
    input_directory: str
    skip_github: bool = False
    enable_llm: bool = False
    enable_ocr: bool = False


class ReviewRequest(BaseModel):
    source_file: str
    decision: str = Field(description="approve, reject, or needs_review")
    notes: str = ""
    score_override: int | None = Field(default=None, ge=0, le=100)


def create_app(database_path: Path = Path("data/screening.db")):
    """Application factory so FastAPI remains an optional dependency."""
    try:
        from fastapi import FastAPI, HTTPException
    except ImportError as exc:
        raise RuntimeError("Install requirements-optional.txt to run the FastAPI service") from exc

    store = ScreeningStore(database_path)
    app = FastAPI(title="AI Resume Screening API", version="1.1.0")

    @app.get("/health")
    def health() -> dict[str, str]:
        return {"status": "ok"}

    @app.post("/screen")
    def screen(request: ScreenRequest) -> dict:
        input_directory = Path(request.input_directory)
        if not input_directory.is_dir():
            raise HTTPException(status_code=400, detail="input_directory does not exist or is not a directory")
        result = screen_resumes(
            input_directory,
            database_path.parent / "cache",
            Settings(),
            skip_github=request.skip_github,
            enable_llm=request.enable_llm,
            enable_ocr=request.enable_ocr,
        )
        run_id = store.save_run(result, str(input_directory))
        reviewed = store.apply_reviews(result)
        return {"run_id": run_id, "batch_summary": reviewed["batch_summary"], "review_overrides_applied": reviewed["review_overrides_applied"]}

    @app.get("/results")
    def latest_results() -> dict:
        latest = store.latest_result()
        if not latest:
            raise HTTPException(status_code=404, detail="No screening run has been saved yet")
        run_id, result = latest
        return {"run_id": run_id, "result": store.apply_reviews(result)}

    @app.get("/results/{run_id}")
    def results_for_run(run_id: int) -> dict:
        result = store.result_for_run(run_id)
        if not result:
            raise HTTPException(status_code=404, detail="Screening run not found")
        return {"run_id": run_id, "result": store.apply_reviews(result)}

    @app.post("/reviews")
    def add_review(review: ReviewRequest) -> dict:
        try:
            saved = store.save_review(
                review.source_file,
                review.decision,
                review.notes,
                review.score_override,
            )
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return {"source_file": review.source_file, "review": saved}

    return app

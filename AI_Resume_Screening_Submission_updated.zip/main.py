#!/usr/bin/env python3
"""CLI entry point for the AI resume screening assignment."""

from resume_screening.cli import main


if __name__ == "__main__":
    raise SystemExit(main())

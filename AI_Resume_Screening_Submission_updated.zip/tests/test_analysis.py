from resume_screening.analysis import evaluate_candidate
from resume_screening.models import CandidateResult
from resume_screening.parsers import extract_name, normalise_extracted_text


def candidate() -> CandidateResult:
    return CandidateResult(source_file="synthetic.pdf", candidate_name="Test Candidate")


def test_rejects_javascript_only_profile() -> None:
    text = "Skills: JavaScript React Next.js. Built responsive web applications and REST APIs."
    result = evaluate_candidate(candidate(), text)
    assert not result.eligible
    assert any("Python" in reason for reason in result.rejection_reasons)
    assert any("AI" in reason for reason in result.rejection_reasons)


def test_accepts_python_agentic_rag_profile() -> None:
    text = """
    Projects: Built a Python FastAPI customer-support assistant using LangGraph.
    Implemented RAG with embeddings, Pinecone vector search, retrieval, tool calling,
    stateful workflows, evaluation tests, PostgreSQL, Redis, Docker, and GCP deployment.
    """
    result = evaluate_candidate(candidate(), text)
    assert result.eligible
    assert result.score_breakdown["ai_project_depth"] >= 26
    assert result.score_breakdown["python_backend"] >= 20
    assert result.score_breakdown["project_quality_penalty"] == 0


def test_applies_shallow_wrapper_penalty() -> None:
    text = "Projects: Built a Python chatbot as a thin wrapper around an OpenAI API call. Skills: LangChain."
    result = evaluate_candidate(candidate(), text)
    assert result.eligible
    assert result.score_breakdown["project_quality_penalty"] <= -5
    assert result.score_breakdown["ai_project_depth"] <= 14


def test_repairs_spaced_pdf_text_and_contact_heavy_name_lines() -> None:
    text = normalise_extracted_text("M A N O J K U M A R\nSkills: P y t h o n and R A G workflows")
    assert "Python" in text
    assert "RAG" in text
    assert extract_name("ABHINAV MISHRA Ghaziabad | abhinav@example.com", "candidate_10") == "Abhinav Mishra"
    assert extract_name("Sumaiya Sultana Shaiksultanasumaiya623@gmail.com", "candidate_28") == "Sumaiya Sultana"
    assert extract_name("MANOJ KUMAR K Rmano@gmail.com", "candidate_21") == "Manoj Kumar K R"

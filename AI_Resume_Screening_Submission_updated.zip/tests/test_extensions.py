import json
from pathlib import Path
from tempfile import TemporaryDirectory

from resume_screening.config import Settings
from resume_screening.parsers import detect_sections
from resume_screening.pipeline import screen_resumes
from resume_screening.report import write_html_report
from resume_screening.storage import ScreeningStore


FIXTURES = Path(__file__).parent / "fixtures"


def test_section_detector_finds_resume_sections() -> None:
    sections = detect_sections("SUMMARY\nPython engineer\nTECHNICAL SKILLS\nPython\nPROJECTS\nBuilt a RAG system")
    assert sections == ["summary", "skills", "projects"]


def test_golden_batch_and_html_report() -> None:
    with TemporaryDirectory() as directory:
        output = Path(directory)
        result = screen_resumes(FIXTURES / "resumes", output, Settings(), skip_github=True)
        expected = json.loads((FIXTURES / "expected_summary.json").read_text(encoding="utf-8"))
        assert result["batch_summary"] == expected
        assert [candidate["source_file"] for candidate in result["ranked_eligible_candidates"]] == [
            "ai_engineer.txt",
            "shallow_llm.txt",
        ]
        report = output / "insights.html"
        write_html_report(result, report)
        page = report.read_text(encoding="utf-8")
        assert "Resume Screening Insights" in page
        assert "Ada Lovelace" in page


def test_reviewer_override_persists_and_rebuilds_rankings() -> None:
    with TemporaryDirectory() as directory:
        directory_path = Path(directory)
        result = screen_resumes(FIXTURES / "resumes", directory_path, Settings(), skip_github=True)
        store = ScreeningStore(directory_path / "screening.db")
        store.save_review("shallow_llm.txt", "approve", "Reviewed AI project manually.", score_override=95)
        reviewed = store.apply_reviews(result)
        assert reviewed["ranked_eligible_candidates"][0]["source_file"] == "shallow_llm.txt"
        assert reviewed["ranked_eligible_candidates"][0]["review"]["decision"] == "approve"
